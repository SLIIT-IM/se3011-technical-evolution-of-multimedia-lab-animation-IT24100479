float x = 0;

void setup(){
  size(500,500);
}

void draw(){
  background(255);
  
  ellipse(x,height/2,30,30);
  x = x + 4;
}
