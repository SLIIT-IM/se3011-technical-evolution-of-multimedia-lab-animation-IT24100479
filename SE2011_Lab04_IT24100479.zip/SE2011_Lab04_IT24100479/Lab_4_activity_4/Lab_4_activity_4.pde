float px = 350, py = 175;
float step = 6;
float pr = 20;

void setup() {
  size(700, 350);
}

void draw() {
  background(240);

  if (keyPressed) {
    if (keyCode == RIGHT) px += step;
    if (keyCode == LEFT)  px -= step;
    if (keyCode == DOWN)  py += step;
    if (keyCode == UP)    py -= step;
  }

  px = constrain(px, pr, width - pr);
  py = constrain(py, pr, height - pr);

  fill(60, 120, 200);
  ellipse(px, py, pr*2, pr*2);
}
