float x = -15;
float speed = 4;
boolean trails = false;

void setup() {
  size(700, 350);
}

void draw() {
  if (!trails) {
    background(255);
  } else {
    noStroke();
    fill(255, 35);
    rect(0, 0, width, height);
  }

  fill(50, 130, 240);
  ellipse(x, height/2, 30, 30);

  x += speed;

  if (x > width + 15) {
    x = -15;
  }

  fill(0);
  textSize(16);
  text("Trails: " + (trails ? "ON" : "OFF") + " (Press T)", 20, 25);
}

void keyPressed() {
  if (key == 't' || key == 'T') {
    trails = !trails;
  }
}
