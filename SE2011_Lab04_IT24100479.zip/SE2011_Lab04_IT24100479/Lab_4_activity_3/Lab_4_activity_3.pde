float x = 100, y = 100;
float xs = 4, ys = 3;
float r = 20;

void setup() {
  size(700, 350);
}

void draw() {
  background(245);

  x += xs;
  y += ys;

  if (x > width - r || x < r) xs *= -1;
  if (y > height - r || y < r) ys *= -1;

  fill(255, 120, 80);
  ellipse(x, y, r*2, r*2);

  fill(0);
  textSize(16);
  text("Press + to speed up | - to slow down", 20, 25);
}

void keyPressed() {
  if (key == '+') { xs *= 1.2; ys *= 1.2; }
  if (key == '-') { xs *= 0.8; ys *= 0.8; }
}
