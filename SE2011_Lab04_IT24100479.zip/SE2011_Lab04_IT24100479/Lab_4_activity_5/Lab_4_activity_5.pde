float px = 350, py = 175;
float step = 6;
float pr = 20;

float hx, hy;
float ease = 0.10;

void setup() {
  size(700, 350);
  hx = px;
  hy = py;
}

void draw() {
  background(255);

  if (keyPressed) {
    if (keyCode == RIGHT) px += step;
    if (keyCode == LEFT)  px -= step;
    if (keyCode == DOWN)  py += step;
    if (keyCode == UP)    py -= step;
  }

  px = constrain(px, pr, width - pr);
  py = constrain(py, pr, height - pr);

  hx = hx + (px - hx) * ease;
  hy = hy + (py - hy) * ease;

  fill(60, 120, 200);
  ellipse(px, py, pr*2, pr*2);

  fill(80, 200, 120);
  ellipse(hx, hy, 16, 16);

  fill(0);
  text("Helper follows using easing", 20, 25);
}
