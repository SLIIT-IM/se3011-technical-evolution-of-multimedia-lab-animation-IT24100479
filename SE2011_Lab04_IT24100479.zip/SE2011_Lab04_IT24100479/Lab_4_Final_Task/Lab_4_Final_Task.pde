float px = 350, py = 175;
float step = 6;
float pr = 20;
float hx, hy;
float ease = 0.10;
int state = 0;
int startTime;
int duration = 30;
float x = 100, y = 100;
float xs = 4, ys = 3;
float r = 20;
float score = 0;
boolean trails = false;

void setup() {
  size(700, 350);
  hx = px;
  hy = py;
}

void draw() {
  background(245);

  if (state == 0) {
    textAlign(CENTER, CENTER);
    textSize(24);
    fill(0);
    text("Press ENTER to Start", width/2, height/2);
  }

  if (state == 1) {
    if (keyPressed) {
    if (keyCode == RIGHT) px += step;
    if (keyCode == LEFT)  px -= step;
    if (keyCode == DOWN)  py += step;
    if (keyCode == UP)    py -= step;
    }

    px = constrain(px, pr, width - pr);
    py = constrain(py, pr, height - pr);
    
    hx = hx + (px - hx) * ease;
    hy = hy + (py - hy) * ease;
    
    if (!trails) {
      background(255);
    } else {
      noStroke();
      fill(255, 35);
      rect(0, 0, width, height);
    }
    
    fill(0);
    textSize(16);
    text("Trails: " + (trails ? "ON" : "OFF") + " (Press T)", 400, 20);
    
    x += xs;
    y += ys;
    
    fill(60, 120, 200);
    ellipse(px, py, pr*2, pr*2);
    
    fill(80, 200, 120);
    ellipse(hx, hy, 16, 16);
  
    if (x > width - r || x < r) xs *= -1;
    if (y > height - r || y < r) ys *= -1;
  
    fill(255, 120, 80);
    ellipse(x, y, r*2, r*2);
    
    int elapsed = (millis() - startTime) / 1000;
    int left = duration - elapsed;

    textAlign(LEFT, TOP);
    textSize(18);
    fill(0);
    text("Time Left: " + left, 20, 20);
    
    if(px == x || py == y){
      score ++;
      x += xs;
      y += ys;
    }
    
    textAlign(RIGHT, TOP);
    textSize(18);
    fill(0);
    text("Score: " + score, 650, 20);

    if (left <= 0) {
      state = 2;
    }
  }

  if (state == 2) {
    textAlign(CENTER, CENTER);
    textSize(24);
    fill(0);
    text("Time Over! Press R to Reset", width/2, height/2);
    text("Score: " + score, 325, 250);
  }
}

void keyPressed() {
  if (state == 0 && keyCode == ENTER) {
    state = 1;
    startTime = millis();
  }

  if (state == 2 && (key == 'r' || key == 'R')) {
    state = 0;
  }
  
  if (key == 't' || key == 'T') {
    trails = !trails;
  }
}
