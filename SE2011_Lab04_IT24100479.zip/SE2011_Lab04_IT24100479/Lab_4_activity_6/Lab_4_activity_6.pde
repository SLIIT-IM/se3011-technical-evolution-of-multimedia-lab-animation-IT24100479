int state = 0;
int startTime;
int duration = 20;

void setup() {
  size(700, 350);
}

void draw() {
  background(245);

  if (state == 0) {
    textAlign(CENTER, CENTER);
    textSize(24);
    fill(0);
    text("Press ENTER to Start", width/2, height/2);
  }

  if (state == 1) {
    int elapsed = (millis() - startTime) / 1000;
    int left = duration - elapsed;

    textAlign(LEFT, TOP);
    textSize(18);
    fill(0);
    text("Time Left: " + left, 20, 20);

    if (left <= 0) {
      state = 2;
    }
  }

  if (state == 2) {
    textAlign(CENTER, CENTER);
    textSize(24);
    fill(0);
    text("Time Over! Press R to Reset", width/2, height/2);
  }
}

void keyPressed() {
  if (state == 0 && keyCode == ENTER) {
    state = 1;
    startTime = millis();
  }

  if (state == 2 && (key == 'r' || key == 'R')) {
    state = 0;
  }
}
